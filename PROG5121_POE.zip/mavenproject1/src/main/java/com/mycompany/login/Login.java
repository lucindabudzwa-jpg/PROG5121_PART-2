package com.mycompany.login;

import java.util.regex.Pattern;

public class Login {
    private String registeredUsername, registeredPassword, firstName, lastName, phone;

    public void setFirstName(String f) { this.firstName = f; }
    public void setLastName(String l) { this.lastName = l; }

    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        String regex = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[^a-zA-Z0-9]).{8,}$";
        return Pattern.compile(regex).matcher(password).matches();
    }

    public boolean checkCellPhoneNumber(String phone) {
        return phone.startsWith("+27") && phone.substring(3).length() <= 10;
    }

    public String registerUser(String user, String pass, String phone) {
        if (!checkUserName(user)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(pass)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(phone)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }
        
        this.registeredUsername = user;
        this.registeredPassword = pass;
        this.phone = phone;
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    public boolean loginUser(String user, String pass) {
        return user.equals(this.registeredUsername) && pass.equals(this.registeredPassword);
    }

    public String returnLoginStatus(boolean success) {
        if (success) return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
}
