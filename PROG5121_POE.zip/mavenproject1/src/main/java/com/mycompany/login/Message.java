package com.mycompany.login;

import java.util.Random;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;

public class Message {
    private static String allMessagesReport = "";
    private static int totalMessagesSent = 0;

    public boolean checkMessageID(String id) {
        return id != null && id.length() == 10;
    }

    public boolean checkRecipientCell(String cell) {
        return cell.matches("^\\+27[0-9]{9}$");
    }

    public String createMessageHash(String id, int num, String text) {
        String[] words = text.trim().split("\\s+");
        String first = (words.length > 0) ? words[0] : "VOID";
        String last = (words.length > 0) ? words[words.length - 1] : "VOID";
        
        first = first.replaceAll("[^a-zA-Z]", "").toUpperCase();
        last = last.replaceAll("[^a-zA-Z]", "").toUpperCase();
        
        return id.substring(0, 2) + ":" + num + ":" + first + last;
    }

    
    public String printMessages() {
        return allMessagesReport;
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    public static void runMessageMenu(Scanner input) {
        System.out.println("\nWelcome to QuickChat");
        String choice = "";
        while (!choice.equals("3")) {
            System.out.println("\n--- QuickChat Menu ---");
            System.out.println("1) Send Messages\n2) Show recently sent messages\n3) Quit");
            System.out.print("Choice: ");
            choice = input.nextLine();

            if (choice.equals("1")) {
                sendMessageFlow(input);
            } else if (choice.equals("2")) {
                System.out.println("Coming Soon."); 
            }
        }
    }

    private static void sendMessageFlow(Scanner input) {
        System.out.print("How many messages? ");
        int count = Integer.parseInt(input.nextLine());
        Message tool = new Message();

        for (int i = 0; i < count; i++) {
            System.out.print("\nRecipient: "); String rec = input.nextLine();
            System.out.print("Message: "); String txt = input.nextLine();

            if (txt.length() > 250) {
                System.out.println("Message too long.");
            } else {
                String id = ""; Random r = new Random();
                for (int j = 0; j < 10; j++) id += r.nextInt(10);
                String hash = tool.createMessageHash(id, totalMessagesSent, txt);

                System.out.println("1) Send\n2) Disregard\n3) Store");
                String action = input.nextLine();
                if (action.equals("1")) {
                    System.out.println("Sent.");
                    totalMessagesSent++;
                    allMessagesReport += "ID: " + id + "\nHash: " + hash + "\nRec: " + rec + "\nMsg: " + txt + "\n\n";
                } else if (action.equals("3")) {
                    saveToJSON(id, hash, rec, txt);
                    System.out.println("Stored.");
                }
            }
        }
    }

    private static void saveToJSON(String id, String hash, String rec, String txt) {
        try (FileWriter writer = new FileWriter("messages.json", true)) {
            String json = "{\n \"id\": \"" + id + "\", \"hash\": \"" + hash + "\", \"rec\": \"" + rec + "\", \"msg\": \"" + txt + "\"\n}\n";
            writer.write(json);
        } catch (IOException e) {}
    }
}