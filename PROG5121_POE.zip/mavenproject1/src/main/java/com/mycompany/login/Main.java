package com.mycompany.login;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login auth = new Login();

        System.out.println("===== REGISTRATION =====");
        System.out.print("First Name: "); String fn = input.nextLine();
        auth.setFirstName(fn);
        System.out.print("Last Name: "); String ln = input.nextLine();
        auth.setLastName(ln);
        System.out.print("Username: "); String un = input.nextLine();
        System.out.print("Password: "); String pw = input.nextLine();
        System.out.print("Phone: "); String ph = input.nextLine();

        String regResult = auth.registerUser(un, pw, ph);
        System.out.println("\n" + regResult);

        if (regResult.contains("successfully added")) {
            System.out.println("\n===== LOGIN =====");
            System.out.print("Username: "); String lUn = input.nextLine();
            System.out.print("Password: "); String lPw = input.nextLine();

            boolean isSuccess = auth.loginUser(lUn, lPw);
            System.out.println(auth.returnLoginStatus(isSuccess));

            if (isSuccess) {
                Message.runMessageMenu(input);
            }
        }
    }
}