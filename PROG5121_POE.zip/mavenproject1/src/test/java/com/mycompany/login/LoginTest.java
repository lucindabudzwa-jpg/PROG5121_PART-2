package com.mycompany.login;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {

    Login auth = new Login();

    @Test
    public void testUsernameCorrect() {
        // Test a valid username (has underscore, <= 5 chars)
        assertTrue(auth.checkUserName("js_1"));
    }

    @Test
    public void testUsernameIncorrect() {
        // Test invalid username (no underscore)
        assertFalse(auth.checkUserName("john1"));
    }

    @Test
    public void testPasswordComplexitySuccess() {
        // Test valid password
        assertTrue(auth.checkPasswordComplexity("Ch@t2026!"));
    }

    @Test
    public void testPasswordComplexityFailure() {
        // Test invalid password (no special char or number)
        assertFalse(auth.checkPasswordComplexity("password"));
    }
}
