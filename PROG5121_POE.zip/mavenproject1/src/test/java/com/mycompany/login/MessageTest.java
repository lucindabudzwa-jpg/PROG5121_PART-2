package com.mycompany.login;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    @Test
    public void testCheckMessageID() {
        Message instance = new Message();
        assertTrue(instance.checkMessageID("1234567890"));
        assertFalse(instance.checkMessageID("123"));
    }

    @Test
    public void testCheckRecipientCell() {
        Message instance = new Message();
        // POE Test Data (Page 16)
        assertTrue(instance.checkRecipientCell("+27718693002"));
        assertFalse(instance.checkRecipientCell("08966553"));
    }

    @Test
    public void testCreateMessageHash() {
        Message instance = new Message();
        // POE Test Data (Page 16)
        String id = "0012345678"; 
        int num = 0;
        String text = "Hi Mike, can you join us for dinner tonight?";
        
        
        String expected = "00:0:HITONIGHT";
        String result = instance.createMessageHash(id, num, text);
        
        assertEquals(expected, result);
    }

    @Test
    public void testReturnTotalMessages() {
        Message instance = new Message();
        int result = instance.returnTotalMessages();
        assertTrue(result >= 0);
    }
}